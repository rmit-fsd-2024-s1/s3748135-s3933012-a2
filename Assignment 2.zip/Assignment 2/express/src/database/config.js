module.exports = {
  HOST: "rmit.australiaeast.cloudapp.azure.com",
  USER: "s3933012_fsd_a2",
  PASSWORD: "akshat@12",
  DB: "s39733012_fsd_a2",
  DIALECT: "mysql"
};
