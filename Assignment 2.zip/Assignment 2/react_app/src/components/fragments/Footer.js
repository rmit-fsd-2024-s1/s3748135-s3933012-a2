function Footer() {
    return (
      <footer style={{ backgroundColor: '#333', color: 'white', padding: '10px', textAlign: 'center', position: "fixed", left: '0', bottom: '0', width: '100%' }}>
        <p>© 2024 SOIL Organic Grocer. All rights reserved.</p>
      </footer>
    );
  }
  
  export default Footer;
  